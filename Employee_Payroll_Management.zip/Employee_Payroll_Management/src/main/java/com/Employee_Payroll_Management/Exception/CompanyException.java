package com.Employee_Payroll_Management.Exception;

public class CompanyException extends Exception {
	public CompanyException(String msg) {
 	   super(msg);
    }
}
