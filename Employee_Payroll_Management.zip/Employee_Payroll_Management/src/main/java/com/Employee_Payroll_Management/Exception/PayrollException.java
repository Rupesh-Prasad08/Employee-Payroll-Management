package com.Employee_Payroll_Management.Exception;

public class PayrollException extends Exception {
	public PayrollException(String msg) {
	 	   super(msg);
	    }
	}