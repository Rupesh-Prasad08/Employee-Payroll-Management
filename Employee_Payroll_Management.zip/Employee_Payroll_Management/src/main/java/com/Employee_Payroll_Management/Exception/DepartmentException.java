package com.Employee_Payroll_Management.Exception;

public class DepartmentException extends Exception {
	public DepartmentException(String msg) {
	 	   super(msg);
	    }
	}
