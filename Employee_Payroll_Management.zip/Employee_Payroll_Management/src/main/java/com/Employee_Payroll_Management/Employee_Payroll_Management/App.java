package com.Employee_Payroll_Management.Employee_Payroll_Management;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
